DROP DATABASE IF EXISTS toll;
CREATE DATABASE IF NOT EXISTS toll;
USE toll;

CREATE TABLE Vare (
    vare_id INT PRIMARY KEY,
    navn VARCHAR(255),
    beskrivelse VARCHAR(255)
);

CREATE TABLE Ansatt (
    ansatt_id INT PRIMARY KEY,
    navn VARCHAR(255),
    stilling VARCHAR(255)
);

CREATE TABLE Beslag (
    beslag_id INT PRIMARY KEY,
    ansatt_id INT,
    tidspunkt TIMESTAMP,
    FOREIGN KEY (ansatt_id) REFERENCES Ansatt(ansatt_id)
);

CREATE TABLE BeslagVarer (
    beslag_id INT,
    vare_id INT,
    FOREIGN KEY (beslag_id) REFERENCES Beslag(beslag_id),
    FOREIGN KEY (vare_id) REFERENCES Vare(vare_id)
);

INSERT INTO Vare (vare_id, navn, beskrivelse)
VALUES (1, 'Kokain', 'Ulovlig narkotisk stoff'),
       (2, 'Rolex', 'Falsk klokke'),
       (3, 'Sprit', '20 års aldersgrense'),
       (4, 'Svalerede', 'Delikatesse. Ulovlig å importere'),
       (5, 'Hvit snus', 'Ulovlig å importere'),
       (6, 'Designer-veske', 'Falsk'),
       (7, 'Marihuana', 'Ulovlig narkotisk stoff'),
       (8, 'Vape', 'Nikotinholdig preparat som er ulovlig å importere'),
       (9, 'Pibullterrier', 'Ulovlig hunderase'),
       (10, 'Kalasjnikov', 'Ulovlig våpen'),
       (11, 'Kastestjerne', 'Ulovlig våpen');

INSERT INTO Ansatt (ansatt_id, navn, stilling)
VALUES (1, 'Billy Betong', 'Tollinspektør'),
       (2, 'Ragna Rekkverk', 'Tollinspektør'),
       (3, 'Pelle Parafin', 'Tollbetjent'),
       (4, 'Leon Latex', 'Tollbetjent'),
       (5, 'Sandra Salamander', 'Tollbetjent');

INSERT INTO Beslag (beslag_id, ansatt_id, tidspunkt)
VALUES (1, 1, '2024-01-23 17:30:00'),
       (2, 2, '2024-01-23 18:00:00'),
       (3, 3, '2024-01-23 19:00:00'),
       (4, 1, '2024-01-23 20:00:00'),
       (5, 2, '2024-01-23 21:00:00'),
       (6, 3, '2024-01-24 10:00:00'),
       (7, 4, '2024-01-24 11:00:00'),
       (8, 4, '2024-01-24 12:00:00'),
       (9, 1, '2024-01-24 13:00:00'),
       (10, 2, '2024-01-24 14:00:00');

INSERT INTO BeslagVarer (beslag_id, vare_id)
VALUES (1, 1),
       (2, 2),
       (3, 3),
       (4, 4),
       (5, 5),
       (1, 2),
       (2, 3),
       (3, 4),
       (4, 5),
       (5, 1),
       (6, 6),
       (7, 7),
       (8, 8),
       (9, 9),
       (10, 10),
       (6, 2),
       (7, 1),
       (8, 3),
       (9, 4),
       (10, 5);