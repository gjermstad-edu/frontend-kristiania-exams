DROP DATABASE IF EXISTS rental;
CREATE DATABASE rental;
USE rental;

CREATE TABLE Person (
    PersonID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(20) NOT NULL
);

CREATE TABLE SportAndLeisureItem (
    ItemID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    DailyPrice INT NOT NULL,
    RentOutDate DATE,
    PersonID INT NOT NULL,

    Season VARCHAR(50) NOT NULL,
    NumberOfUsers INT NOT NULL,

    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);


CREATE TABLE PartyItem (
    ItemID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    DailyPrice INT NOT NULL,
    RentOutDate DATE,
    PersonID INT NOT NULL,

    Quantity INT NOT NULL,
    IsElectronic BOOLEAN NOT NULL,
    RequiresCleaning BOOLEAN NOT NULL,

    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE ToolItem (
    ItemID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    DailyPrice INT NOT NULL,
    RentOutDate DATE,
    PersonID INT NOT NULL,

    PowerType VARCHAR(50) NOT NULL,
    RequiresSafetyGear BOOLEAN NOT NULL,

    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);
